export default {
    PRODUCTS: 'products',
    CATEGORIES: 'categories',
    LAYOUT: 'layout',
    USERS: 'users',
    OTP: 'otp',
    CART: 'cart',
    WISHLIST: 'wishlist',
    CUPONS: 'cupons',
    ORDERS: 'orders',
    REVIEWS: 'reviews',
    VENDORS: 'vendors',
    ADDRESS: 'address',
    ADMIN: 'admin'
}