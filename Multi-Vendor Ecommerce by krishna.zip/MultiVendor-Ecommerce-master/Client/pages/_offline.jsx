import Offline from "@/Component/Offline/Offline"

function _offline() {
  return (
    <Offline />
  )
}

export default _offline